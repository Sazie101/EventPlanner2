CREATE OR ALTER PROCEDURE usp_InsertEvent
@EventName NVARCHAR(50), 
@EventDescription NVARCHAR(MAX),
@EventDate DATETIME, 
@EventLocation NVARCHAR(MAX),
@EventCapacity INT
AS
BEGIN

BEGIN TRY

BEGIN TRANSACTION
	INSERT INTO Events(EventName, EventDescription, EventDate, EventLocation, EventCapacity)
	VALUES(@EventName, @EventDescription, @EventDate, @EventLocation, @EventCapacity)
COMMIT TRANSACTION

END TRY

BEGIN CATCH
	IF @@TRANCOUNT > 0 
		ROLLBACK TRANSACTION
END CATCH

END