CREATE OR ALTER PROCEDURE usp_UpdateEvent
    @EventId INT,
    @EventName NVARCHAR(50), 
    @EventDescription NVARCHAR(MAX),
    @EventDate DATETIME, 
    @EventLocation NVARCHAR(MAX),
    @EventCapacity INT
AS 
BEGIN
    BEGIN TRY
        BEGIN TRANSACTION
            UPDATE Events
            SET 
                EventName = @EventName, 
                EventDescription = @EventDescription,
                EventDate = @EventDate,
                EventLocation = @EventLocation,
                EventCapacity = @EventCapacity
            WHERE 
                EventId = @EventId;

        COMMIT TRANSACTION;
    END TRY
    BEGIN CATCH
        IF(@@TRANCOUNT > 0) 
            ROLLBACK TRANSACTION;
    END CATCH;
END;
